# Welcome to Python Application Programming Course
# conducted by N S Kumar, Nirupama, Prajwala, Chaitra, Savitha 

# email: ask.kumaradhara@gmail.com

# programming language
#	designed by Guido van Rossum
#	python.org
#		tutorial
#	named after Monty Python show
#	
#	interpreted language
#	python on import creates an intermediate language file .pyc
#		which is later interpreted
#	easy and safe language
#	scripting language:
#		no declaration of variable wrt type
#		no build cycle
#		(compile, link => build cycle)
#		development is short
#		type: two things; range of values and set of operations
#		type is weak or dynamic
#		python : type is dynamic and type can change at runtime
#		fool = 100   => int
#		fool = "stupid"  => str

print ("hello world")
print ("ondu")
print ("eradu")
print ("mooru")
import test
# print (a) # NameError

