# program structure
#	case sensitive
#	no entry fn - no main
#	any expr is a stmt	
#	not a free format source code language
#	a stmt should be on a single line
#	stmt on multiple lines:
#	a) escape the newline with a backslash
#	b) use constructs which has beginning and ending markers
#	more than one stmt on a single line
#	use ; as a separator
#	stmt in the beginning should start from the first col only
#Print("nalku")
print # fn name => expr => stmt
("hadimooru") # => expr => stmt
3 + 4 # no change of state!!
# error : string cannot span multiple lines
#
#print ("
#testing
#")

print ("idu"\
)
print( [
	"aaru", "elu",
	"entu"
])
a = 10; b = 20
# print("hattu") # NO
print("over")
